<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize form fields
    $name = filter_var(trim($_POST["name"]), FILTER_SANITIZE_STRING);
    $tel = filter_var(trim($_POST["tel"]), FILTER_SANITIZE_STRING);
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $subject = filter_var(trim($_POST["subject"]), FILTER_SANITIZE_STRING);
    $message = filter_var(trim($_POST["message"]), FILTER_SANITIZE_STRING);

    // Validate required fields
    if (empty($name) || empty($tel) || empty($email) || empty($subject) || empty($message)) {
        $response = array(
            "status" => "error",
            "message" => "Oops! There was a problem with your submission. Please complete all required fields and try again."
        );
        echo json_encode($response);
        exit;
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response = array(
            "status" => "error",
            "message" => "Oops! Invalid email address. Please provide a valid email address."
        );
        echo json_encode($response);
        exit;
    }

    // Create the email content
    $email_content = "Name: $name\n";
    $email_content .= "Phone Number: $tel\n";
    $email_content .= "Email: $email\n";
    $email_content .= "Subject: $subject\n";
    $email_content .= "Message: $message\n";
     $email_content .= "This mail is from Arcoinfra Tech Private Limited Website";

    // Update this with your desired email address
    $recipient = "mohsinmaqbool9797@gmail.com";

    // Set email headers
    $headers = "From: $name <$email>\r\n";
    $headers .= "Reply-To: $email\r\n";

    // Send the email
    if (mail($recipient, $subject, $email_content, $headers)) {
        $response = array(
            "status" => "success",
            "message" => "Thank you! Your message has been sent."
        );
        echo json_encode($response);
    } else {
        $response = array(
            "status" => "error",
            "message" => "Oops! Something went wrong and we couldn't send your message."
        );
        echo json_encode($response);
    }
} else {
    $response = array(
        "status" => "error",
        "message" => "There was a problem with your submission, please try again."
    );
    echo json_encode($response);
}
?>
